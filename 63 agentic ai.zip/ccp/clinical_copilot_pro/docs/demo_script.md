# Demo script

1. Problem: multiple vital streams can create noisy alerts; the prototype focuses on multi-parameter trajectories.
2. Live stream: start the simulator and show changing HR, SpO₂, RR and BP.
3. Deterioration: select P104 and show coordinated HR increase, SpO₂ decrease and RR increase.
4. Explainability: show the specific reasons and local grounding returned by the evidence layer.
5. Human-in-the-loop: demonstrate Accept, Dismiss, Defer and Investigate.
6. Audit: show system escalation and clinician action records, then export CSV.
