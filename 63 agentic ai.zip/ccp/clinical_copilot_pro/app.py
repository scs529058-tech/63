import time
import pandas as pd
import streamlit as st
from simulator import PatientSimulator
from engine import DeteriorationEngine
from audit import AuditDB
from evidence import EvidenceRetriever

st.set_page_config(
    page_title="Sentinel Clinical Copilot",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------- State ----------
if "sim" not in st.session_state: st.session_state.sim = PatientSimulator()
if "engine" not in st.session_state: st.session_state.engine = DeteriorationEngine()
if "db" not in st.session_state: st.session_state.db = AuditDB()
if "evidence" not in st.session_state: st.session_state.evidence = EvidenceRetriever()
if "running" not in st.session_state: st.session_state.running = False
if "last_tick" not in st.session_state: st.session_state.last_tick = 0.0

sim, engine, db, evidence = (
    st.session_state.sim, st.session_state.engine,
    st.session_state.db, st.session_state.evidence
)

# ---------- Modern UI ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] { font-family: Inter, sans-serif; }
.stApp { background: #07111f; color: #e8eef7; }
.block-container { max-width: 1500px; padding-top: 1.4rem; padding-bottom: 3rem; }
section[data-testid="stSidebar"] { background: #0a1627; border-right: 1px solid #1c3048; }
h1,h2,h3 { letter-spacing: -0.02em; }
.hero { padding: 24px 28px; border: 1px solid #203751; border-radius: 22px;
        background: linear-gradient(135deg,#0d1d32,#0a1424); margin-bottom: 18px; }
.hero-title { font-size: 30px; font-weight: 800; margin: 0; }
.hero-sub { color:#9db0c7; margin-top:7px; font-size:14px; }
.eyebrow { color:#6ed6ff; font-size:11px; font-weight:800; letter-spacing:.14em; text-transform:uppercase; }
.card { background:#0c1a2c; border:1px solid #203751; border-radius:18px; padding:18px; }
.card-title { font-size:13px; color:#91a7bf; font-weight:700; text-transform:uppercase; letter-spacing:.06em; }
.metric-big { font-size:27px; font-weight:800; margin-top:6px; }
.muted { color:#91a7bf; font-size:12px; }
.patient-card { background:#0c1a2c; border:1px solid #203751; border-radius:18px; padding:16px; min-height:205px; }
.patient-name { font-weight:750; font-size:16px; }
.status-high { color:#ff8b8b; }
.status-medium { color:#ffd36e; }
.status-low { color:#70e3ad; }
.risk-high { background:linear-gradient(135deg,#35151d,#1e1119); border:1px solid #9b3c4d;
             padding:17px; border-radius:16px; }
.risk-medium { background:linear-gradient(135deg,#342713,#201b0f); border:1px solid #8d7130;
               padding:17px; border-radius:16px; }
.risk-low { background:linear-gradient(135deg,#102d24,#0d201b); border:1px solid #28694e;
            padding:17px; border-radius:16px; }
.risk-title { font-size:18px; font-weight:800; }
.reason { background:#0a1524; border:1px solid #1c3048; border-radius:12px; padding:11px 13px; margin:7px 0; }
.reason strong { color:#dce8f6; }
.risk-panel { background:#0b1728; border:1px solid #203751; border-radius:16px; padding:15px; margin-bottom:10px; }
.risk-panel h4 { margin:0 0 7px 0; }
.risk-panel p { color:#a9b8ca; font-size:13px; line-height:1.5; margin:5px 0; }
.warning { background:#211b0c; border:1px solid #695724; border-radius:12px; padding:12px; color:#d9c891; font-size:12px; }
div[data-testid="stMetric"] { background:#0c1a2c; border:1px solid #203751; padding:13px 15px; border-radius:16px; }
div[data-testid="stMetricLabel"] { color:#91a7bf; }
.stButton button { border-radius:10px; font-weight:650; }
</style>
""", unsafe_allow_html=True)

# ---------- Risk knowledge shown in UI ----------
RISK_CONTEXT = {
    "Acute cardiovascular & systemic": [
        ("Hypovolemic / septic shock pattern",
         "An elevated HR together with falling SBP can be consistent with severe volume depletion or systemic infection. This pattern is a risk signal, not a diagnosis."),
        ("Hypertensive / hyperadrenergic pattern",
         "Simultaneously elevated HR and SBP can accompany acute sympathetic activation and, in the appropriate clinical context, severe hypertension or other hyperadrenergic states."),
        ("Cardiac rhythm / failure concern",
         "Unexpected HR spikes or drops, particularly when persistent or accompanied by other abnormalities, can warrant assessment for arrhythmia or cardiovascular deterioration."),
    ],
    "Respiratory & hypoxemic": [
        ("Respiratory failure / hypoxia pattern",
         "Falling SpO₂ together with rising RR is a concerning oxygenation/respiratory pattern that can occur with conditions such as pneumonia, asthma or COPD exacerbation."),
        ("Pulmonary embolism pattern",
         "An abrupt combination of falling SpO₂, rising RR and HR, especially with falling SBP, can occur with acute pulmonary vascular compromise and requires urgent clinical assessment."),
        ("Metabolic acidosis pattern",
         "Markedly elevated RR with preserved SpO₂ can occur during metabolic crises such as diabetic ketoacidosis; blood gas and laboratory data are required to evaluate this possibility."),
    ],
    "Chronic / autonomic": [
        ("Long-term cardiovascular risk",
         "Persistently elevated resting HR and SBP are associated in population studies with cardiovascular risk. Longitudinal context matters more than a single reading."),
        ("Orthostatic hypotension pattern",
         "A substantial SBP fall after standing, without an appropriate HR response, can be consistent with orthostatic hypotension and should be evaluated with the clinical context."),
        ("Autonomic stress / allostatic load",
         "Persistent physiologic stress patterns may reflect altered autonomic regulation. HRV is context-sensitive and should not be interpreted as a standalone diagnosis of burnout, depression or immune dysfunction."),
    ],
}

st.markdown("""
<div class="hero">
  <div class="eyebrow">SENTINEL • CLINICAL COPILOT</div>
  <div class="hero-title">Clinical Deterioration & Escalation Dashboard</div>
  <div class="hero-sub">Synthetic streaming vitals → trends → explainable risk patterns → evidence → human decision → audit</div>
</div>
""", unsafe_allow_html=True)

# ---------- Sidebar ----------
with st.sidebar:
    st.markdown("### Control Center")
    a, b = st.columns(2)
    if a.button("▶ Start", use_container_width=True):
        st.session_state.running = True
    if b.button("⏸ Pause", use_container_width=True):
        st.session_state.running = False
    if st.button("↻ Reset Demo", use_container_width=True):
        sim.reset(); engine.reset(); db.clear()
        st.session_state.running = False
        st.session_state.last_tick = 0.0
        st.rerun()
    interval = st.slider("Simulation interval", 0.5, 5.0, 1.2, 0.1)
    st.divider()
    st.markdown("**Pipeline**")
    st.code("Stream\n  ↓\nPatient State\n  ↓\nTrend Features\n  ↓\nRisk + Prioritization\n  ↓\nEvidence + Explain\n  ↓\nHuman Decision\n  ↓\nAudit Trail")
    st.divider()
    st.markdown('<div class="warning">Synthetic data only. Prototype thresholds are not medical advice and must not be used for real patient care.</div>', unsafe_allow_html=True)

# ---------- Streaming ----------
if st.session_state.running and time.time() - st.session_state.last_tick >= interval:
    for reading in sim.tick():
        event = engine.process(reading, sim.patient_profiles[reading["patient_id"]])
        if event["new_escalation"]:
            event["evidence"] = evidence.retrieve(reading, event)
            db.log_event(reading, event, "SYSTEM")
    st.session_state.last_tick = time.time()
    st.rerun()

# ---------- Cohort ----------
rows = []
for pid, profile in sim.patient_profiles.items():
    state = sim.get_state(pid)
    risk = engine.assess(pid, state)
    rows.append({
        "Patient": pid, "Name": profile["display_name"], "Age": profile["age"],
        "HR": round(state["heart_rate"]), "SpO₂": f'{state["spo2"]:.0f}%',
        "RR": round(state["resp_rate"]), "BP": f'{state["sbp"]:.0f}/{state["dbp"]:.0f}',
        "Risk": risk["level"], "Score": risk["score"]
    })
cohort = pd.DataFrame(rows)
high = int((cohort.Risk == "HIGH").sum())
med = int((cohort.Risk == "MEDIUM").sum())

m1, m2, m3, m4 = st.columns(4)
m1.metric("Patients monitored", len(cohort))
m2.metric("High risk", high)
m3.metric("Medium risk", med)
m4.metric("Open escalations", len(engine.open_escalations))

st.markdown("### Live Patient Cohort")
st.dataframe(cohort, use_container_width=True, hide_index=True)

# ---------- Patient cards ----------
st.markdown("### Patient Monitoring")
cols = st.columns(4)
for col, (pid, profile) in zip(cols, sim.patient_profiles.items()):
    state = sim.get_state(pid); risk = engine.assess(pid, state)
    cls = risk["level"].lower()
    with col:
        st.markdown(f"""
        <div class="patient-card">
          <div class="muted">{pid}</div>
          <div class="patient-name">{profile["display_name"]}</div>
          <div class="muted">{profile["age"]} years • {profile["history"]}</div>
          <br>
          <div class="card-title">Risk status</div>
          <div class="metric-big status-{cls}">{risk["level"]} · {risk["score"]}/10</div>
          <div class="muted">SpO₂ {state["spo2"]:.0f}% · HR {state["heart_rate"]:.0f} · RR {state["resp_rate"]:.0f}</div>
          <div class="muted">BP {state["sbp"]:.0f}/{state["dbp"]:.0f} mmHg</div>
        </div>
        """, unsafe_allow_html=True)

# ---------- Investigation ----------
st.markdown("### 🔎 Investigation & Explainable Escalation")
selected = st.selectbox(
    "Select patient", list(sim.patient_profiles),
    format_func=lambda x: f"{x} — {sim.patient_profiles[x]['display_name']}"
)
profile = sim.patient_profiles[selected]
state = sim.get_state(selected)
risk = engine.assess(selected, state)

left, right = st.columns([0.95, 1.55])
with left:
    st.markdown("#### Patient context")
    st.markdown(f'<div class="card"><b>Age</b> {profile["age"]}<br><br><b>History</b> {profile["history"]}<br><br><b>Medications</b> {profile["medications"]}<br><br><b>Recent labs</b> {profile["recent_labs"]}</div>', unsafe_allow_html=True)
    st.markdown("#### Current vitals")
    vc1, vc2 = st.columns(2)
    vc1.metric("Heart rate", f'{state["heart_rate"]:.0f} bpm')
    vc2.metric("SpO₂", f'{state["spo2"]:.0f}%')
    vc1.metric("Respiratory rate", f'{state["resp_rate"]:.0f} /min')
    vc2.metric("Blood pressure", f'{state["sbp"]:.0f}/{state["dbp"]:.0f}')

with right:
    st.markdown(f"""
    <div class="risk-{risk["level"].lower()}">
      <div class="risk-title">Current status: {risk["level"]}</div>
      <div>Prototype risk score: <b>{risk["score"]}/10</b></div>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("#### Why is this patient being flagged?")
    if risk["reasons"]:
        for reason in risk["reasons"]:
            st.markdown(f'<div class="reason">• {reason}</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="reason">No meaningful multi-parameter deterioration pattern detected.</div>', unsafe_allow_html=True)

    rec = (
        "Escalate for prompt clinician review and investigate the combined trend."
        if risk["level"] == "HIGH"
        else "Continue closer monitoring and review if the trajectory persists or worsens."
        if risk["level"] == "MEDIUM"
        else "Continue routine prototype monitoring."
    )
    st.info(rec)

    st.markdown("#### Risk-pattern context")
    matched = evidence.match_risk_patterns(state, engine.histories.get(selected, []))
    if matched:
        for item in matched:
            st.markdown(f"""
            <div class="risk-panel">
              <h4>{item["title"]}</h4>
              <p>{item["summary"]}</p>
              <div class="muted">Association only • clinical confirmation required</div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.caption("No additional named risk pattern matched the current synthetic state.")

    st.markdown("#### Retrieved grounding")
    for item in evidence.retrieve(state, risk):
        st.markdown(f'**{item["title"]}** — {item["summary"]}')
        if item.get("url"):
            st.markdown(f'[Source / reference]({item["url"]})')

    st.markdown("#### Clinician decision")
    ac = st.columns(4)
    for col, action in zip(ac, ["Accept", "Dismiss", "Defer", "Investigate"]):
        with col:
            if st.button(action, key=f"{action}_{selected}", use_container_width=True):
                db.log_clinician_action(selected, action, risk, rec)
                engine.record_human_action(selected, action)
                st.success(f"{action} recorded.")

# ---------- Trends ----------
st.markdown("### 📈 Live Physiologic Trends")
hist = pd.DataFrame(sim.history(selected))
if not hist.empty:
    st.caption("Separate scales preserve visibility of each vital sign. Trends are synthetic and intended for demonstration.")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Heart rate (bpm)**")
        st.line_chart(hist.set_index("time")[["heart_rate"]], height=220)
        st.markdown("**SpO₂ (%)**")
        st.line_chart(hist.set_index("time")[["spo2"]], height=220)
    with c2:
        st.markdown("**Respiratory rate (/min)**")
        st.line_chart(hist.set_index("time")[["resp_rate"]], height=220)
        st.markdown("**Blood pressure — systolic (mmHg)**")
        st.line_chart(hist.set_index("time")[["sbp"]], height=220)

# ---------- Risk framework ----------
st.markdown("### 🧠 Risk Framework")
st.caption("These are contextual patterns for explainability, not automated diagnoses.")
for category, items in RISK_CONTEXT.items():
    with st.expander(category, expanded=True):
        for title, summary in items:
            st.markdown(f'<div class="risk-panel"><h4>{title}</h4><p>{summary}</p></div>', unsafe_allow_html=True)

# ---------- Audit ----------
st.markdown("### 📋 Audit Trail")
audit = db.recent_events(100)
if audit:
    adf = pd.DataFrame(audit)
    st.dataframe(adf, use_container_width=True, hide_index=True)
    st.download_button(
        "Download audit trail CSV", adf.to_csv(index=False).encode(),
        "clinical_copilot_audit.csv", "text/csv"
    )
else:
    st.info("No audit events yet.")

if st.session_state.running:
    time.sleep(0.05)
    st.rerun()
