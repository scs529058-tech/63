import sqlite3
import json
from datetime import datetime


class _JSONSafeEncoder(json.JSONEncoder):
    """Serialize common Python containers used by the prototype audit payload."""
    def default(self, obj):
        if isinstance(obj, set):
            return sorted(obj)
        return super().default(obj)


class AuditDB:
    """Small local SQLite audit store for the prototype."""

    def __init__(self, path="copilot_audit.db"):
        self.path = path
        self._init()

    def _connect(self):
        return sqlite3.connect(self.path)

    def _init(self):
        with self._connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    patient_id TEXT,
                    actor TEXT,
                    event TEXT,
                    risk_level TEXT,
                    risk_score INTEGER,
                    details TEXT
                )
            """)

    def log_event(self, reading, event, actor):
        details = {
            "vitals": reading,
            "reasons": event.get("reasons", []),
            "evidence": event.get("evidence", []),
        }
        with self._connect() as con:
            con.execute(
                "INSERT INTO audit (timestamp, patient_id, actor, event, risk_level, risk_score, details) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (reading["time"], reading["patient_id"], actor, "System escalation", event.get("level", ""), event.get("score", 0), json.dumps(details, cls=_JSONSafeEncoder)),
            )

    def log_clinician_action(self, pid, action, risk, recommendation):
        with self._connect() as con:
            con.execute(
                "INSERT INTO audit (timestamp, patient_id, actor, event, risk_level, risk_score, details) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (datetime.now().strftime("%H:%M:%S"), pid, "CLINICIAN", f"Clinician action: {action}", risk.get("level", ""), risk.get("score", 0), recommendation),
            )

    def recent_events(self, limit=100):
        with self._connect() as con:
            rows = con.execute(
                "SELECT timestamp, patient_id, actor, event, risk_level, risk_score, details FROM audit ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {"Time": r[0], "Patient": r[1], "Actor": r[2], "Event": r[3], "Risk": r[4], "Score": r[5], "Details": r[6][:250]}
            for r in rows
        ]

    def clear(self):
        with self._connect() as con:
            con.execute("DELETE FROM audit")
