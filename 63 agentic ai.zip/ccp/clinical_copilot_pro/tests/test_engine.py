from engine import DeteriorationEngine

def test_normal_patient_is_low():
    e=DeteriorationEngine(); r=e.assess('P1',{'heart_rate':75,'spo2':98,'resp_rate':16,'sbp':120,'dbp':80}); assert r['level']=='LOW'

def test_multiple_abnormal_signals_raise_risk():
    e=DeteriorationEngine(); r=e.assess('P1',{'heart_rate':130,'spo2':88,'resp_rate':32,'sbp':168,'dbp':95}); assert r['level']=='HIGH'
