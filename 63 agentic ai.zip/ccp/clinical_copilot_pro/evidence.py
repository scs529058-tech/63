class EvidenceRetriever:
    """Small local evidence/risk-pattern layer for the synthetic prototype."""

    REFERENCES = {
        "physiology": "https://pmc.ncbi.nlm.nih.gov/articles/PMC11933627/",
        "vital_signs": "https://www.hopkinsmedicine.org/health/conditions-and-diseases/vital-signs-body-temperature-pulse-rate-respiration-rate-blood-pressure",
        "respiratory": "https://pmc.ncbi.nlm.nih.gov/articles/PMC7665156/",
        "cardiovascular": "https://pmc.ncbi.nlm.nih.gov/articles/PMC3491126/",
        "orthostatic": "https://cardiopt.memberclicks.net/assets/docs/CPG/Joint%20Vital%20Sign%20Booklet.pdf",
    }

    def __init__(self):
        self.items = [
            {
                "title": "Multi-parameter deterioration policy",
                "summary": "Evaluate changes across multiple vital-sign channels and trajectory rather than relying on one isolated reading.",
                "tags": {"trend", "multi-parameter"},
            },
            {
                "title": "Human-in-the-loop escalation policy",
                "summary": "High-risk synthetic events are surfaced with observations and reasoning for human review; the prototype does not make treatment decisions.",
                "tags": {"escalation", "human", "explainability"},
            },
            {
                "title": "Alert-noise policy",
                "summary": "Avoid repeatedly firing the same escalation when there is no meaningful new information; maintain alert state and audit history.",
                "tags": {"alert", "suppression", "audit"},
            },
        ]

    def retrieve(self, state, event):
        tags = {"trend", "multi-parameter"}
        if event.get("level") == "HIGH":
            tags.add("escalation")
        out = []
        for x in self.items:
            if tags & x["tags"]:
                item = {k: v for k, v in x.items() if k != "tags"}
                if "trend" in x["tags"]:
                    item["url"] = self.REFERENCES["physiology"]
                out.append(item)
        return out[:3]

    def match_risk_patterns(self, state, history):
        matched = []
        h = history or []

        hr_up = state["heart_rate"] >= 105
        sbp_low = state["sbp"] < 100
        sbp_high = state["sbp"] >= 160
        spo2_low = state["spo2"] < 92
        rr_high = state["resp_rate"] > 25

        if hr_up and sbp_low:
            matched.append({
                "title": "Hypovolemic / septic shock pattern",
                "summary": "Elevated HR with reduced SBP can be consistent with severe volume depletion or systemic infection. This is a pattern requiring clinical context, not a diagnosis.",
            })
        if hr_up and sbp_high:
            matched.append({
                "title": "Hypertensive / hyperadrenergic pattern",
                "summary": "Elevated HR and SBP can accompany acute sympathetic activation or severe hypertension in the appropriate context. Assess symptoms and confirm measurements clinically.",
            })
        if spo2_low and rr_high:
            matched.append({
                "title": "Respiratory failure / hypoxemia pattern",
                "summary": "Reduced SpO₂ together with tachypnea is a concerning respiratory pattern that can occur with several pulmonary conditions.",
            })
        if spo2_low and rr_high and hr_up and sbp_low:
            matched.append({
                "title": "Acute pulmonary vascular compromise pattern",
                "summary": "An abrupt combination of hypoxemia, tachypnea, tachycardia and hypotension can occur with severe pulmonary vascular compromise, including PE; urgent clinical assessment is required.",
            })
        if rr_high and state["spo2"] >= 94:
            matched.append({
                "title": "Metabolic acidosis pattern",
                "summary": "Marked tachypnea with preserved oxygen saturation can occur during metabolic crises such as DKA. Confirmation requires clinical assessment and laboratory data.",
            })

        if len(h) >= 8:
            first, last = h[-8], h[-1]
            if last["heart_rate"] > 95 and last["sbp"] > 140:
                matched.append({
                    "title": "Long-term cardiovascular risk signal",
                    "summary": "Persistently elevated resting HR and SBP are associated with cardiovascular risk in population studies; longitudinal clinical context is essential.",
                })

        # Orthostatic hypotension cannot be inferred from ordinary streaming data;
        # only show it when a paired positional sequence is explicitly supplied.
        if len(h) >= 2 and h[-1].get("position") == "standing" and h[-2].get("position") == "supine":
            drop = h[-2]["sbp"] - h[-1]["sbp"]
            hr_delta = h[-1]["heart_rate"] - h[-2]["heart_rate"]
            if drop >= 20 and hr_delta < 10:
                matched.append({
                    "title": "Orthostatic hypotension pattern",
                    "summary": "A substantial SBP fall after standing without a proportionate HR response can be consistent with orthostatic hypotension and needs clinical confirmation.",
                })

        if len(matched) > 5:
            matched = matched[:5]
        return matched
