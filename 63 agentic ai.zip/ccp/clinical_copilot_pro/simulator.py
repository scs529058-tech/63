from copy import deepcopy
from datetime import datetime
import math
import random


class PatientSimulator:
    """Synthetic streaming vitals simulator.

    P104 follows a gradual multi-parameter deterioration trajectory and then
    fluctuates around a sustained abnormal state instead of getting pinned to
    artificial min/max values. Other patients show smaller, mean-reverting
    fluctuations so the cohort looks like a live monitor feed.
    """

    BASE_PROFILES = {
        "P101": {
            "display_name": "John Doe", "age": 54,
            "history": "Hypertension",
            "medications": "Antihypertensive (synthetic)",
            "recent_labs": "No acute abnormality (synthetic)",
            "base": dict(heart_rate=78, spo2=98, resp_rate=16, sbp=124, dbp=78),
        },
        "P102": {
            "display_name": "Jane Smith", "age": 67,
            "history": "Chronic respiratory disease",
            "medications": "Maintenance inhaler (synthetic)",
            "recent_labs": "Mild chronic abnormality (synthetic)",
            "base": dict(heart_rate=88, spo2=95, resp_rate=20, sbp=132, dbp=82),
        },
        "P103": {
            "display_name": "Alex Kumar", "age": 42,
            "history": "No major history",
            "medications": "None listed (synthetic)",
            "recent_labs": "Within simulated baseline",
            "base": dict(heart_rate=74, spo2=99, resp_rate=15, sbp=118, dbp=76),
        },
        "P104": {
            "display_name": "Priya Rao", "age": 71,
            "history": "Diabetes",
            "medications": "Glucose-lowering medication (synthetic)",
            "recent_labs": "Glucose elevated in synthetic profile",
            "base": dict(heart_rate=94, spo2=94, resp_rate=21, sbp=142, dbp=88),
        },
    }

    def __init__(self):
        self.reset()

    def reset(self):
        self.patient_profiles = deepcopy(self.BASE_PROFILES)
        self.states = {p: deepcopy(v["base"]) for p, v in self.patient_profiles.items()}
        self.histories = {p: [] for p in self.patient_profiles}
        self.step = 0
        self._phase = {"P101": random.random() * 6, "P102": random.random() * 6,
                       "P103": random.random() * 6, "P104": random.random() * 6}

    @staticmethod
    def _bounded(value, low, high):
        return max(low, min(high, value))

    def _mean_reverting_update(self, current, baseline, noise, pull=0.10):
        return current + pull * (baseline - current) + random.gauss(0, noise)

    def _update_stable_patient(self, pid):
        s = self.states[pid]
        base = self.patient_profiles[pid]["base"]
        phase = self._phase[pid] + self.step * 0.18
        # Small correlated movement + noise: realistic-looking but non-deteriorating.
        pulse = math.sin(phase) * 0.7
        s["heart_rate"] = self._mean_reverting_update(s["heart_rate"], base["heart_rate"] + pulse, 0.75, 0.16)
        s["spo2"] = self._mean_reverting_update(s["spo2"], base["spo2"] + math.sin(phase * 0.7) * 0.15, 0.10, 0.20)
        s["resp_rate"] = self._mean_reverting_update(s["resp_rate"], base["resp_rate"] + math.sin(phase * 0.9) * 0.35, 0.28, 0.16)
        s["sbp"] = self._mean_reverting_update(s["sbp"], base["sbp"] + math.sin(phase * 0.5) * 1.8, 1.0, 0.12)
        s["dbp"] = self._mean_reverting_update(s["dbp"], base["dbp"] + math.sin(phase * 0.5) * 1.0, 0.7, 0.12)

    def _update_deteriorating_patient(self):
        s = self.states["P104"]
        base = self.patient_profiles["P104"]["base"]

        # Phase 1: gradual deterioration. Phase 2: sustained abnormal state
        # with continuing physiologic variation, rather than hard saturation.
        ramp = min(1.0, max(0.0, (self.step - 2) / 42.0))
        target = {
            "heart_rate": base["heart_rate"] + 34 * ramp,
            "spo2": base["spo2"] - 6.0 * ramp,
            "resp_rate": base["resp_rate"] + 9.0 * ramp,
            "sbp": base["sbp"] + 17 * ramp,
            "dbp": base["dbp"] + 8 * ramp,
        }

        phase = self._phase["P104"] + self.step * 0.24
        # Once the deterioration is established, oscillate around the target.
        # This keeps the chart alive while preserving the overall trajectory.
        target["heart_rate"] += 1.8 * math.sin(phase)
        target["spo2"] += 0.35 * math.sin(phase * 0.75)
        target["resp_rate"] += 0.8 * math.sin(phase * 0.8)
        target["sbp"] += 2.5 * math.sin(phase * 0.55)
        target["dbp"] += 1.2 * math.sin(phase * 0.55)

        s["heart_rate"] += 0.24 * (target["heart_rate"] - s["heart_rate"]) + random.gauss(0, 1.0)
        s["spo2"] += 0.20 * (target["spo2"] - s["spo2"]) + random.gauss(0, 0.16)
        s["resp_rate"] += 0.22 * (target["resp_rate"] - s["resp_rate"]) + random.gauss(0, 0.38)
        s["sbp"] += 0.16 * (target["sbp"] - s["sbp"]) + random.gauss(0, 1.3)
        s["dbp"] += 0.16 * (target["dbp"] - s["dbp"]) + random.gauss(0, 0.8)

        # Broad simulation bounds only; these are not deterioration limits.
        s["heart_rate"] = self._bounded(s["heart_rate"], 55, 155)
        s["spo2"] = self._bounded(s["spo2"], 84, 100)
        s["resp_rate"] = self._bounded(s["resp_rate"], 10, 38)
        s["sbp"] = self._bounded(s["sbp"], 85, 185)
        s["dbp"] = self._bounded(s["dbp"], 50, 110)

    def tick(self):
        self.step += 1
        out = []

        for pid in self.patient_profiles:
            if pid == "P104":
                self._update_deteriorating_patient()
            else:
                self._update_stable_patient(pid)

            s = self.states[pid]
            r = {
                "patient_id": pid,
                "time": datetime.now().strftime("%H:%M:%S"),
                "step": self.step,
                **{k: round(v, 1) for k, v in s.items()},
            }
            self.histories[pid].append(r)
            self.histories[pid] = self.histories[pid][-60:]
            out.append(r)

        return out

    def get_state(self, pid):
        return deepcopy(self.states[pid])

    def history(self, pid):
        return deepcopy(self.histories[pid])
