from collections import defaultdict
class DeteriorationEngine:
    def __init__(self): self.reset()
    def reset(self): self.histories=defaultdict(list); self.open_escalations={}; self.last_alert_step=defaultdict(lambda:-9999); self.step=0
    def process(self,reading,profile):
        self.step+=1; pid=reading['patient_id']; self.histories[pid].append(reading); self.histories[pid]=self.histories[pid][-30:]; risk=self.assess(pid,reading)
        new=risk['level']=='HIGH' and self.step-self.last_alert_step[pid]>=6 and pid not in self.open_escalations
        if new: self.open_escalations[pid]={'created_step':self.step,'score':risk['score'],'level':risk['level']}; self.last_alert_step[pid]=self.step
        return {**risk,'new_escalation':new,'patient_id':pid,'context':profile}
    def assess(self,pid,state):
        score=0; reasons=[]; h=self.histories.get(pid,[])
        if state['spo2']<90: score+=3; reasons.append('SpO₂ is markedly below the prototype warning range.')
        elif state['spo2']<94: score+=2; reasons.append('SpO₂ is below the prototype warning range.')
        if state['resp_rate']>30: score+=3; reasons.append('Respiratory rate is markedly elevated.')
        elif state['resp_rate']>24: score+=2; reasons.append('Respiratory rate is elevated.')
        if state['heart_rate']>120: score+=2; reasons.append('Heart rate is markedly elevated.')
        elif state['heart_rate']>100: score+=1; reasons.append('Heart rate is elevated.')
        if state['sbp']<90 or state['sbp']>160: score+=2; reasons.append('Systolic blood pressure is outside the prototype warning range.')
        if len(h)>=5:
            f,l=h[-5],h[-1]; fs=l['spo2']<=f['spo2']-2; rr=l['resp_rate']>=f['resp_rate']+4; hr=l['heart_rate']>=f['heart_rate']+15; n=sum([fs,rr,hr])
            if fs: score+=1; reasons.append('SpO₂ has been trending downward over recent readings.')
            if rr: score+=1; reasons.append('Respiratory rate has been trending upward.')
            if hr: score+=1; reasons.append('Heart rate has been trending upward.')
            if n>=2: score+=2; reasons.append('Multiple physiologic signals are changing together, increasing concern for a persistent trajectory.')
        score=min(10,score); level='HIGH' if score>=6 else 'MEDIUM' if score>=3 else 'LOW'
        return {'score':score,'level':level,'reasons':reasons}
    def record_human_action(self,pid,action):
        if action in {'Accept','Dismiss'}: self.open_escalations.pop(pid,None)
